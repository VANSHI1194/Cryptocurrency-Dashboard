export function toPercent(num) {
   return `${new Number(num).toFixed(2)}%`;
}

